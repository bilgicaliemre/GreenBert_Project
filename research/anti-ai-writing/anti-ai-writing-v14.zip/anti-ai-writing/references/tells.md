# AI-writing tells: catalog and fixes

Ordered the way to audit: content first, words last. Each entry: what to look for, a short example,
the fix. Entries marked "strong" justify an edit on one sighting. "Strong in aggregate" or "at paragraph
level" means act on the pattern across the piece, not on one instance; treat unmarked entries the same way. The
weak tells in section 9 never justify an edit alone.

Contents
1. Content
2. Staging and structure
3. Inflation and tone
4. Personal-essay tells
5. Rhythm and punctuation
6. Vocabulary (current models, then classic)
7. Formatting
8. Over-corrections to avoid
9. When not to act
10. Human signals worth keeping

---

## 1. Content (fix these first; they drive expert judgments)

**C1 Portability (strong).** A sentence that could move unchanged into another person's essay or another
company's report says nothing. "Teamwork is essential to success." Fix: replace it with what only this
writer knows, or delete it.

**C2 Categories instead of instances (strong).** "Many students face various challenges." Fix: the actual
instance the writer has: "Three of us shared one graphing calculator for AP Physics." If the writer has not
supplied an instance, ask; never invent one.

**C3 No stakes, no surprise.** Everything resolves, nothing was at risk, nobody was wrong, no joke. Fix: say
what could have gone wrong, what the writer believed that turned out false, the detail that does not fit.

**C4 Redundant exposition.** Telling the reader what the example just showed: "This shows how important
patience is." Professional editors often cut this in AI drafts. Fix: delete; let the
example work.

**C5 Prompt echo.** Repeating the question's words back ("This challenge helped me grow and taught me
resilience"). Fix: answer with the writer's own material and vocabulary.

**C6 Vague attribution.** "Experts say", "Studies show", "Critics argue". Fix: name the source and what it
said, or cut the claim. Never invent a source.

**C7 Low density.** Defining the obvious, background the reader has, two sentences doing one job. Fix: each
sentence must add a fact, a reason or a step the reader lacks.

## 2. Staging and structure

**S1 Corrective framing (strong).** "It's not X, it's Y", "not just X but Y", "X rather than Y", "less a X
than a Y", "This isn't about X. It's about Y." Test: does anyone in this context actually believe X, and does
rejecting X add information? If not, state Y. "Greenwashing isn't just a marketing problem, it's a governance
failure" becomes "Greenwashing is a governance failure." If the sentence then needs its reason, use the
writer's, or ask: `[ask: why governance?]`.

**S2 Importance flags (strong; very frequent in current Claude).** "This matters because", "Why this
matters:", "This distinction matters", "plays a crucial role", "is key to". Fix: give the consequence:
"Because the report never defines net zero, investors cannot check it."

**S3 Run-ups and signposts.** "Here's the thing", "Let's break this down", "In this essay I will explore",
"The answer? Simple." Fix: start with the claim. (Signposting in research papers is a convention; see
`research.md`.)

**S4 "-ing" tails (strong).** A clause tacked on to interpret the fact: "Emissions fell 4%, highlighting the
company's commitment to sustainability." Fix: cut the tail: "Emissions fell 4%." If the source gives something
to measure the fact against (a target, last year's figure), state that; if it does not, leave the fact alone or
ask: `[ask: against what target?]`.

**S5 Arguing with no one.** "Some might argue…", "To be clear, this isn't to say…", "Don't get me wrong". Fix:
keep an objection only if a real person or source raised it (name them), or if it is the strongest objection a
fair reader would raise; answer it either way.

**S6 Summary closers (strong at paragraph level).** A last sentence restating the paragraph; "In
conclusion"; "Ultimately,"; a final paragraph that repeats the introduction. Fix: end on the last new point,
an implication, or a concrete next step. A required conclusion must still do new work.

**S7 Upbeat send-offs.** "Looking ahead", "What comes next", "paving the way", "The future looks bright". Fix:
state the actual next step or the limit.

**S8 Forced triads.** Three adjectives, three parallel clauses, three examples, every time. Fix: keep the
items that are distinct and true. Vary list lengths.

**S9 Fragment stacks and one-line punchlines.** "No baseline. No audit. No accountability." A one-sentence
paragraph after every section. Fix: one sentence carrying the specific claim.

**S10 Tradeoff-dodging.** "without sacrificing", "without compromising", "without losing". Fix: report the
real tradeoff or say it was not measured.

**S11 Kicker endings everywhere (strong in aggregate; the main tell that anti-AI rewrites create).** Five of
seven paragraphs end on a short wry, poignant or quotable line ("The map stayed in the glovebox." "He never
asked again." "Nobody did."). One such ending can be the best line in the piece; a pattern of them is a
rhythm signature. Fix: keep the strongest one or two; end the other paragraphs on their last piece of
content, or merge the kicker into the sentence before it. A short last sentence that simply gives the final
fact, result or request is not a kicker; leave it.

**S12 Staged self-correction.** Stating something false in order to reverse it ("I've never lost a chess
game. Actually, that stopped being true two weeks ago."). Fine once if it is the writer's real
habit of speech; a structural device if it repeats. Fix: state the true version directly.

## 3. Inflation and tone

**T1 Significance inflation.** "marked a pivotal moment", "a testament to", "reflects a broader shift",
"setting the stage for", "an enduring legacy". Fix: keep the fact, drop the verdict.

**T2 Rating adjectives instead of description.** meaningful, thoughtful, powerful, remarkable, dependable,
steady, valuable, profound, incredible. "She did meaningful work" says nothing. Fix: the observable fact that
earned the rating.

**T3 Intensifiers and sincerity markers.** genuinely, truly, deeply, incredibly, absolutely, "every single",
"the single most", "honestly". Fix: delete; if the sentence collapses, it needed evidence, not emphasis.

**T4 Mannered prose.** Metaphor performing cleverness: "trust is the currency of reporting", "the quiet work
of", "load-bearing", "has teeth", "earns its keep", "a mirror, not a window". Fix: the literal statement.

**T5 Hedge stacks.** "could potentially suggest", "may arguably". Fix: one hedge, on the uncertain part. Keep
hedges that carry real uncertainty (results, small samples).

**T6 False balance.** "While X offers benefits, it also presents challenges." Fix: take the position the
evidence supports and say how strong it is.

**T7 Positivity bias.** Problems renamed opportunities; dark facts skipped. Fix: let negative facts stay
negative.

**T8 Chatbot residue.** "Great question", "I hope this helps", "Let me know if…", "Certainly!". Delete.

**T9 Sycophantic feedback.** "What a powerful essay!" Fix: the most important problem first, with a concrete
fix; praise only specific lines that work.

## 4. Personal-essay tells

**PE1 Generic lessons.** "This experience taught me the value of hard work and perseverance." A moral any
applicant could claim. Fix: the student's own conclusion, specific to them, stated once; or the changed behavior
in one concrete moment. Stating a lesson is not itself the tell: admitted essays written before 2022 say
"learned" about four times as often as an early version of this skill (v7) did, and more often than a plain model.

**PE2 Tidy epiphany.** Problem, struggle, sudden insight, better person, all resolved by the last paragraph.
Fix: keep whatever is really unresolved; end on the student's actual conclusion, or on an open question only if the student is in fact unsure.

**PE3 Inflated essay nouns.** "my journey of growth", "a testament to my resilience", "a deep appreciation
for". Earlier models overused these words; current models already avoid them, and pre-2022 admitted essays use
challenge, passion, experiences and world more often than current model versions do. Fix only the inflated use
(the event behind the word); a plain "challenge" or "community" is fine.

**PE4 Résumé in prose.** Titles and awards strung together. Fix: one activity, one moment inside it.

**PE5 Identity as a label.** "As the daughter of immigrants, I am a bridge between two cultures." Fix: a scene
in which the identity does something.

**PE6 Stock self-metaphors.** Journey, tapestry, puzzle, mosaic, symphony, compass, spark. Fix: one literal
sentence.

**PE7 Stage directions around dialogue.** "she said with a knowing smile". Fix: keep the line, drop the
direction unless it adds information.

**PE8 Hardship resolved into gratitude.** Illness or loss turned into growth within a paragraph. Fix: let the
hard part stay hard.

**PE10 The cool essay (what a model writing from spoken notes produces; anti-AI rules make it worse).** Speech filler carried over from notes
("kind of wild", "so cringy", "basically", "super"), a flat factual first sentence followed by background,
framing devices ("(I counted)", "the obvious suspects were my parents", "The easy answer is... The harder answer
is..."), and an ending that shrugs ("I still don't know", "but it's okay") in place of the student's real
conclusion. In our tests an early version of this skill (v7) used "really" four times as often as 24 admitted essays, and "kind
of" 15 times where the admitted essays never used it. Fix: the student's written register and their actual conclusion (see `personal-essay.md`
section 1).

**PE11 The engineered essay (the most cited sign in blind tests).** Every thread tied off: a bookend to the
opening image, a motif that returns, paragraphs closing on a sentence that explains their scene ("That was when I
understood..."), connecting sentences that point out what rhymes, signposts ("The strange part was"), and a
balanced, hedged lesson ("both good and bad, and I think..."). Judges cited tidy structure in about four of five
judgments of model essays written without the rules in `personal-essay.md` (about half once they were applied),
and in few of real students' essays. Fix: a looser
structure, scenes left to stand, one whole-hearted conclusion.

**PE9 The over-corrected essay (what anti-AI passes produce).** Every lesson removed and nothing put in its
place: the notes reordered one paragraph per topic, paragraphs opening like interview answers ("The thing I'm
weirdly good at is…"), no reflection, no arc, the most uncomfortable material left out because it was hard to
place. Readers find it vivid but flat: "so what?". Fix: build on one spine with a turn, use the writer's own
reflections (see `personal-essay.md` sections 3 and 5), and include the highest-stakes true material.

## 5. Rhythm and punctuation

**R1 Uniform sentence length (strong in aggregate).** Six sentences of 18 to 22 words. Fix: vary length where
the meaning changes pace: short for the key point, longer for a qualified explanation. Never chop at random.

**R2 Uniform paragraphs.** Every paragraph four sentences. Fix: let length follow content.

**R3 Repeated openers.** "This approach… This approach… This approach…", or many sentences opening with a
generic "A [noun]…" that read like maxims ("A fee that… A fine that… A toll that…"). Fix: merge or
restructure; give sentences real subjects (people, the school, the writer).

**R4 Elegant variation.** Renaming the same thing each time (Unilever, the firm, the conglomerate, the
multinational). AI text is more lexically varied than human text. Fix: repeat the precise term.

**R5 Colons and semicolons.** Model text uses more of both than real writing of the same kind, and readers
cite them. Fix: a comma or a full stop; keep a colon only before a list, a quote or a link, and use
parentheses for a true aside. Never add either mark for variety.

**R6 Em dashes.** Readers and teachers treat them as an AI sign even though current models rarely use them.
Default: avoid them; use a comma, a full stop or parentheses. A user's own drafts or style rules override this.

## 6. Vocabulary (last pass; rewrite the sentence, never just swap the word)

Current Claude-era tells (2026 measurements, ratios vs human web writing):
"this matters" / "why X matters" / "matters because"; "is more than a X, it is"; "rather than simply";
"rather than merely"; "less like X and more like Y"; "looking ahead"; "what comes next"; genuinely;
"the single most"; "arguably the most"; deliberate; dependable; steady; thoughtful; meaningful; "can help you";
"makes it easier"; quietly; plainly; precisely; load-bearing; "the real question".

Classic list (2023 to 2025, still read as AI by teachers): delve, underscore, showcase, highlight (verb),
intricate, meticulous, realm, pivotal, crucial, foster, enhance, leverage, utilize, facilitate, garner,
bolster, boast (meaning "has"), tapestry, testament, vibrant, landscape (abstract), multifaceted, nuanced,
comprehensive, seamless, groundbreaking, transformative, navigate (abstract), "in today's fast-paced world",
"ever-evolving", "plays a crucial role", "a testament to", "shed light on", "pave the way", "it's important to
note", "it's worth noting", Additionally / Furthermore / Moreover / Notably opening several sentences.

Plain-verb swaps that are always fine: serves as → is; boasts → has; utilize → use; facilitate → help;
commence → start; endeavor → try.

## 7. Formatting

- Bullets where an argument belongs. Write paragraphs; keep lists for real steps or parallel items.
- Bold run-in labels ("**Transparency:** Transparency is…"). Turn into prose.
- Title Case Headings and a heading every 100 words. Use sentence case, and headings only where a reader
  navigates.
- Emoji in anything formal. Remove.
- Markdown residue (`**`, `##`) in text pasted into Word or a form. Remove.

## 8. Over-corrections to avoid (what bad "humanizers" do)

- Adding typos or grammar errors. Lowers quality; perfect grammar is not an AI sign.
- Thesaurus swaps. AI text is already too varied; rarer synonyms make it worse.
- Chopping sentences into fragments for "burstiness". Fragment runs are a tell of their own.
- Forced slang, "tbh", jokes, contractions in a formal genre. Register mismatch is a tell.
- Copying the spoken register of interview notes into an essay (really, kind of, actually, stuff).
- Replacing every stated conclusion with a shrug or an open question.
- Ending every paragraph with a short aphorism or wry kicker. Measured as the main new tell that humanizer
  rewrites create, and it showed up in our own tests of this skill.
- Removing every reflection along with the stated lessons, so a personal essay becomes a list of facts.
- Stripping every hedge, or adding hedges to sound humble.
- Meaning drift: rewriting so freely that claims change.
- Inventing specifics to cure vagueness. Never.
- Erasing the writer's voice by polishing everything to the same smooth surface.
- Editing to a detector score. Detectors misfire on careful human writing (in one study they flagged 61% of
  essays by non-native English writers); optimize for the reader instead.

## 9. When not to act

- Quotations, titles, names, and text written before late 2022.
- Technical senses: robust (statistics), significant (with a test), landscape (terrain), key (music,
  cryptography), load-bearing (engineering).
- One weak tell alone: a transition word, one dash, passive voice, formal vocabulary, curly quotes.
- Genre conventions: headings, conclusions and limitations in papers; numbered steps in instructions.
- A non-native writer's formal style. Do not push it toward a template.

## 10. Human signals worth keeping (never fake them)

Concrete names, dates, numbers and objects; small true anecdotes; plain verbs; definite statements when
true; casual qualifiers in informal writing ("pretty", "sort of"); parenthetical asides; an occasional
exclamation in informal writing; repeating the right word; sentence length that follows meaning; unusual
precise words; short real quotes worked into sentences; endings that stop on a specific point; mixed
feelings and unresolved questions; earnest conclusions the writer actually holds.

---
Evidence base (2023 to 2026): Wikipedia "Signs of AI writing"; Kobak et al., Science Advances 2025 (excess
vocabulary in 15M abstracts); Reinhart et al., PNAS 2025 (participial clauses, nominalizations); Russell,
Karpinska and Iyyer, ACL 2025 (expert detectors); Chakrabarty, Laban and Wu, CHI 2025 (professional edits of
AI text); Lee, Alvero, Joachims and Kizilcec 2025 (30,000 admissions essays vs LLM essays); Graphite "AI
Tells" studies, Sep and Oct 2026; Peng et al. 2026 (corrective framing); Liang et al. 2023 (detector bias);
Creanga and Dinu 2026 (humanizer side effects); blader/humanizer issue #229 (over-correction measurements).
