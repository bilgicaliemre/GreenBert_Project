# Personal essays and college applications

Contents
1. What the reader is looking for
2. Ground rules (coach, don't ghostwrite)
3. Step 1: interview for material, including the reflection
4. Step 2: find the spine
5. Step 3: shape (arc, reflection, endings)
6. Step 4: the student drafts
7. Step 5: the admissions-reader critique
8. Step 6: corrections
9. Short answers and supplements
10. Writing a full sample (a fictional person, or a draft the student asked for)

---

## 1. What the reader is looking for

Admissions officers read an essay to meet a specific 17-year-old, not to grade prose. Yale's officers say
they want to finish an essay with "a sense of what it would be like to have a real conversation with this
person". MIT: "this is not a writing test." The most common failure is not bad grammar but "OK, so what?":
a polished essay that could belong to anyone. Yale's description of AI-written essays is "slick but soulless".

What admitted essays have in common:
- **Specific, slightly odd detail** the reader could not have guessed: icing "that tasted like sand",
  sourdough "that required a saw to slice"; a town whose residents "have still not entirely mastered the four-way
  stop sign that was installed five years ago" (Johns Hopkins, Essays That Worked).
- **Insight earned by a scene**, stated in a sentence or two, after the reader has already seen it:
  "Charlie noticed me, ignored the food, and turned without hesitation to meet me at the entrance. That was
  trust." (Hamilton).
- **A moment of being wrong, small or unfinished.** Yale singles out students who "sit in the experience of
  being wrong about something", without wallowing.
- **A voice that sounds like a smart teenager writing carefully**, not talking and not a thesaurus. Yale's
  warning ("when you use a word like 'alacrity', when 'speed' would work just as well…") is about showing off,
  not about formality: admitted essays are written a notch above speech.
- **Plain handling of hard facts.** One understated sentence, then agency: "Today, Feb. 24, 2022, my life was
  upended when my city was bombed. I never managed to retrieve my backpack." (Hamilton).
- **A shape.** Something is different at the end than at the start, and the reader understands why these
  details belong in one essay.

Admitted essays are not flawless; several contain a cliché or end on a tidy moral. They work because nearly
every paragraph is concrete and could only belong to that writer. Aim for a high ratio of concrete to abstract,
not for zero imperfections. Over-editing is itself a red flag to readers.

Two opposite failures to avoid:
- **The AI essay:** a clean arc held together by invented feelings and stated lessons ("The garage taught me a
  different kind of focus").
- **The over-corrected essay:** every lesson removed and nothing put in its place, so the essay is the
  interview notes in a new order, vivid but flat.
Two more failures come from how current models write from spoken notes; anti-AI rules make the first one worse:
- **The cool essay:** speech filler carried over from the notes ("kind of wild", "so cringy", "basically"), a flat
  factual first sentence, framing devices ("(I counted)", "the obvious suspects were my parents"), and an ending
  that shrugs ("I still don't know", "but it's okay") where the student's real conclusion should be. Judges in our
  tests singled out its put-on casual register.
- **The engineered essay:** every thread tied off. An image from the opening returns at the end, paragraphs
  close by explaining what their scene meant, connecting sentences point out what rhymes, and the lesson arrives
  balanced and hedged ("both good and bad, and I think accepting it made me happier"). In blind tests this was
  the most cited sign of a model essay: about four of five judgments of plain-model and early-skill essays, and
  about half once the rules below were applied.
The fix for all four is the same: an arc made of true events and reflection in the writer's own words, written
in the student's careful written voice.

**What admitted essays look like on the page.** We compared 24 essays that Hamilton, Johns Hopkins, Tufts, MIT and
Connecticut College published as examples (all written before 2022) with model-written versions of the same
stories:
- Sentences average about 18 words, and about one in nine runs past 30. Model versions average 11 to 16 words
  and rarely run long.
- Fewer contractions than model versions (about 1.4 per 100 words against 2 to 3), but they are there: "I'd",
  "it's", "weren't". Speech filler (really, kind of, actually, stuff) is rare; none of the 24 says "kind of".
- They say what the student learned or now believes, plainly and usually once, near the end. "Learned",
  "world", "experiences" and "challenge" are all more frequent in them than in model versions.
- They end committed: what the student believes, values, wants or will do, sometimes in large terms. The lesson
  is stated whole-heartedly, never balanced against its opposite or hedged.
- Their structure is loose: the story in order, a list of what the student learned, a year-by-year account, a
  side detail the student cared about. Few callbacks, and scenes are left to stand without a sentence explaining
  them.
- Somewhere they reach: a dramatic first line, a vivid simile, a bigger word than speech would use.
- They open in many ways: a dramatic scene, a bold claim, a line of dialogue, a list, a plain fact.
- They differ from one another far more than model versions do.
These describe the genre; they are not targets. Do not add long sentences or lessons to hit a number.

## 2. Ground rules (coach, don't ghostwrite)

For the three Coach cases in SKILL.md (admission essays and supplements for colleges and the programs they run,
such as the Common App and YYGS; schoolwork the user says will be graded or handed in as their own; an
application or form whose rules require the applicant's own writing or ban AI-written text):

You do:
- interview the student to surface material and their own reflections (section 3);
- help choose the spine and a structure, as a plan in your words, built from their answers;
- critique drafts as an admissions reader would, quoting their lines;
- return their draft with outright errors (spelling, grammar, punctuation) fixed in place, then the list of
  what you fixed ("line 4: 'alot' → 'a lot'") and of the bigger changes they should make themselves.

You do not:
- write the essay (unless the student explicitly asks for a full draft; see "Full draft on request" in SKILL.md
  and section 10), rewrite or rephrase its sentences, or write example sentences built from the student's story
  (model sentences make every student sound alike, and rephrasing for clarity shifts meaning and voice; to show
  a technique, use a neutral example from `examples.md`);
- invent or embellish any experience, feeling, quote, detail or number.

Say why once, briefly and without lecturing: the Common App fraud policy names "the substantive content or
output of an artificial intelligence platform" presented as one's own; Yale and programs such as YYGS require
the essays to be the applicant's own work; officers describe AI essays as generic; and Claude's text carries
a watermark that approved organizations can check. Then get to work. The coaching route also produces the
better essay, because the details and the thinking that make these essays work exist only in the student.

## 3. Step 1: interview for material, including the reflection

Ask a few questions at a time, conversationally. Follow every answer with probes until you have a scene:
**when exactly, where, who was there, what was said word for word, what it looked/smelled/sounded like, what
number, what you did next.**

Material questions (pick what fits):
- What do you do on a normal Saturday? Walk me through it hour by hour.
- What are you weirdly good at that nobody asks about?
- What do your friends tease you about?
- What object in your room would confuse a stranger? Why is it there?
- What's something you believed until recently? What changed your mind?
- Tell me about a time you were wrong in a way that embarrassed you. What did you do the next day?
- What do you do for your family that doesn't show up on the activities list?
- What's a rule you made for yourself? Have you broken it?
- What's the most specific number in your life right now (a count, a time, a score) and what's behind it?

Depth questions (these produce the vulnerability and the reflection; ask them about the strongest story):
- What's the part of this story you'd rather leave out? Why?
- What were you thinking at that exact moment, not what you think now?
- What did you tell nobody at the time?
- What do you understand now that you didn't then? Say it the way you'd say it to a friend.
- What connects [thing A] and [thing B] for you? Is it a real connection or one you wish were there?
- What's still unresolved? What would change your mind about it?

Write down the student's answers to the depth questions in their own words. Those sentences are the raw
material for the essay's reflection lines. If the student can't answer a depth question, that is useful
too: the essay should not claim an insight they don't have.

Listen for: details with numbers or names; things said with a laugh or a pause; contradictions ("I hate
crowds" + "I work the ticket gate at home games"); anything introduced with "I don't know if this counts".

## 4. Step 2: find the spine

Write back a short list of 2 to 4 candidate spines, each in one line quoting the student's words, with what it
reveals. Recommend one. Choose by:
- **Stakes:** prefer the story where the student was wrong, afraid, ashamed, or not sure, and did something
  about it. The most uncomfortable true material is usually the strongest, if the student is willing.
- **Specificity:** it fails the portability test (no one else could write it).
- **A turn:** something changes between the first and last paragraph.
- **New information:** it shows what the activities list and recommendations cannot.

Then decide what to leave out: material that does not serve the spine goes, however good it is (it can go to a
supplement). Do not leave out the uncomfortable material just because it is hard to place; it is often the
spine.

Topics officers warn about: a résumé in prose; an essay mostly about someone else; hardship told as a list of
suffering without insight; the third-person opening with a "that little girl was me" twist.

## 5. Step 3: shape (arc, reflection, endings)

**Arc.** Order the material by the spine's logic, not by the order of the interview. Each paragraph should
move the story or the thinking forward; a paragraph that only adds another interesting fact is a candidate to
cut. Paragraphs should not open like answers to interview questions ("The thing I'm weirdly good at is…").

Structures:
- **Narrative:** one story, roughly in thirds: the situation and what was at stake, what the student did (and
  got wrong), what changed and what still hasn't. Put any loss or diagnosis early and compress it (Yale:
  "follow Alfred Hitchcock").
- **Montage:** 4 to 7 short sections linked by one thread (an object, a list, a set of files, a recurring
  place), each showing a different side of the student. The thread must be the student's own; do not bring it
  back at the end as a symbol.
- **Extended metaphor:** only if the student already thinks in it. Never impose one.

**Reflection.** One to three sentences, placed after the scene that earns them, that tell the reader
something the facts alone do not: what the writer now notices, doubts or does differently. Rules:
- Use the student's own reflections from the interview (their words, lightly trimmed for grammar).
- State the conclusion plainly. "I learned that…" or "I realized…" is fine when what follows belongs to this
  student; admitted essays use it often. Avoid morals that would fit any essay ("the value of hard work") and
  polished epigrams built to be quoted.
- Say it whole-heartedly. Do not balance it ("both good and bad", "X matters, though Y") or hedge it ("I think",
  "maybe"). It can be large, as long as it is the student's. If the mixed feeling or the doubt is the student's
  own, keep it at the strength they hold it.
- Comment on meaning once, not after every scene: let scenes, quotes and contrasts stand without a sentence
  that explains them.
- A reflection may be a question or a doubt ("I don't know yet whether keeping score made me braver or just
  more careful") when the student really is unsure. Do not turn a conclusion the student holds into a shrug.
- In coach mode, if a needed connection is missing, ask the student for it; do not supply it.

**Openings that work:** start where the material is strongest: a scene with the body in it, a bold claim the
essay then earns, a line someone said, a list, an odd fact. Openings that don't: a thesis about identity or
passion; a dictionary definition; a famous quotation.

**Endings that work:** what the student now believes, values or will do, in their words; the last moment of the
story, then stop; a future scene; a real open question. Endings that don't: a moral that fits any essay; a
restated thesis; a deflating aside added to sound modest ("but it's okay"); a balanced or hedged lesson; a bookend
that returns to the opening image; an object from the first paragraph brought back as a symbol the student never
made.

**Paragraph endings.** Vary them. If every paragraph closes on a short wry line, the essay develops a rhythm
signature readers notice. Keep the one or two best kickers; let other paragraphs end on content.

Give the plan to the student as a beat outline. Each beat points to their material ("beat 2: the night the
freezer failed, the call to the owner") and to the depth answer it needs ("what did you think when
she laughed?"). Do not write the sentences.

## 6. Step 4: the student drafts

Tell the student to write the first draft fast, the way they'd tell it to a cousin in line at a family
reunion (MIT's test), without editing. Over the limit is fine for draft one; 650 is a limit, not a target.

## 7. Step 5: the admissions-reader critique

Read the draft once as an officer with 30 essays left today. Then give feedback in this order, quoting their
lines:
1. **The one biggest problem**, with a concrete step the student can take.
2. **So what?** After reading, what do you know about this person that you didn't before? If the answer is
   generic ("hard-working", "passionate"), say which scene could carry something more specific.
3. **Shape:** is there a turn? Does every paragraph move the spine forward?
4. **Opening:** scene, odd fact or flat statement? If it's a thesis, flag it.
5. **Reflection lines:** for each, name the scene that earns it. Flag reflections that could appear in anyone's
   essay, and flag the opposite problem: no reflection at all.
6. **Vulnerability:** is there a moment the writer is wrong, small or unresolved? Is hardship in proportion?
7. **AI-sounding lines** (see `tells.md` sections 2 and 4): generic lessons that would fit any essay, inflated phrases ("my journey of growth"),
   identity as a label, stock metaphors, tidy bow endings, kicker endings everywhere, words chosen only to show off.
8. **Voice:** lines that don't sound like them writing carefully (too grand, or chattier than they write). Ask a friend: "does this sound like me?"
9. **Length and cuts:** what to cut first to make room for the best scene.
10. **What works:** two or three specific lines and why. No general praise.

## 8. Step 6: corrections

Return the draft with outright errors (grammar, spelling, punctuation) fixed in place and nothing else changed,
then a numbered list: first each fix, quoting the original words, then the bigger changes for the student to
make. Keep their vocabulary even when it is plainer than yours. If a sentence is unclear or needs rewriting for
content, explain the problem and let them rewrite it.

## 9. Short answers and supplements

Full guidance is in `short-answers.md`. In brief:

- **Short takes (35 to 50 words):** read for personality; be specific and a little playful.
  Facts about a famous person or a place say nothing about the writer: make the answer about the writer's own
  connection to it.
- **Stanford roommate note:** habits, rituals, warnings, what you'll drag them to. What would living with you
  be like?
- **"Why us":** past tense evidence (what you already did that connects to a specific program or person), not
  brochure facts in the future tense (Yale). Phrases every applicant writes ("friendships that last a
  lifetime") cost space and say nothing.
- **Intellectual curiosity:** the question itself, how the student first ran into it, what they did about it,
  what they still can't answer.
- Each piece should show something the others don't. Short pieces are harder: every word counts.

## 10. Writing a full sample (a fictional person, or a draft the student asked for)

When asked to demonstrate (teaching, a class example, a test of this skill), you may write a full sample for a
clearly fictional student from supplied notes. The same bar applies to a full draft a real student asks for:
their material stands in for the notes, and every missing detail becomes an `[ask: …]`. Aim for the level of the best admitted essays, which means the
essay needs an arc and a "so what", not only accurate details:
- Draft in the two passes described in SKILL.md step 2: shape first, then the full audit and checks (steps 3 and 4) on
  your own draft.
- Events, people, numbers, quotes and objects come only from the notes.
- Pick the spine with the highest stakes (where the student was wrong, ashamed, afraid or unsure) and build the
  whole essay around it. Bring in other material where it sharpens that spine, plus at most one side detail the notes clearly care about.
- Order by the spine's logic: setup with stakes, the turn, what changed and what hasn't. The order things
  happened is often the right one; do not hold back the strongest scene just so the essay can end on it.
- Register: the notes are how the student talks; the essay is how they write. Drop speech filler (really, kind
  of, actually, basically, stuff, super, honestly) except inside quoted speech, write full sentences and let
  some run long, keep ordinary contractions (don't, it's, I'd) where a careful writer would use them, and keep the
  bigger words the student uses in the notes.
- Structure: let the essay be a little loose, the way admitted essays are. Tell it in order, or as a short list
  of what the student learned, or year by year; a paragraph may carry a side detail the notes care about. Do not
  tie every thread: no bookend, no motif that returns, no closing paragraph that names what each earlier scene
  meant.
- Comment once: let scenes, quotes and contrasts stand on their own, with no sentence after them explaining
  what they meant ("That was when I understood...", "It was my own word for..."). Keep reflection for the end,
  plus at most one line in the middle.
- Reach once or twice where the notes carry strong feeling: a dramatic or vivid sentence, a simile, a bigger
  word the student would use. The rest stays plain.
- No signposts ("The climb I keep thinking about", "The strange part was", "What I didn't expect", "Looking
  back"), and at most one "I think" or "I guess" in the whole essay, none in the conclusion.
- Reflection: use the student's own reflections from the notes first. Do not add connective observations that
  link scenes (two things that rhyme, a pattern across two scenes) unless the notes make the link; judges read
  them as engineered. Do not turn an early object into a closing symbol. Do not add an event, a motive or a feeling the notes contradict
  or do not support.
- Close on the student's own conclusion from the notes, as strongly as the notes hold it and no stronger: no
  shrug, balance or hedge that the notes do not contain.
- Run the paragraph-ending count from SKILL.md step 4; stay under the word limit.
- Put any "sample" label outside the essay text.
